// NEW
#include <fstream>

// Simple SRI::Save (DUMP) and SRI::Load
// error handling to be added shortly

void SRI::Save(vector<string> input)
{
    // --- !!! --- NEEDS MORE ERROR CHECKING
    // keep track of whether or not there is a .sri -- if there isn't, then add
    //      or error
    string filePath = input[0];
    ofstream outfile;
    outfile.open( filePath );

    // load RuleBase and KnowledgeBase
    ruleBase.Export( outfile );
    knowledgeBase.Export( outfile );

    // close file
    outfile.close();

}

void SRI::Load(vector<string> input)
{
    // NEEDS ERROR CHECKING AND HANDLING
    // openfile for reading
    string filePath = input[0];
    string line; // stringholder to run InterpretLine on
    ifstream infile;
    infile.open( filePath );

    // open file, begin reading line by line, and add to SRI via InterpretLine
    // NEEDS ERROR HANDLING
    while( getline(infile, line) )
    {
       InterpretLine( line );
    }

    // close files
    infile.close();
}